مدرّب ارتداد البلياردو - مشروع Android

هذا مشروع Android Studio يحوّل نسخة HTML إلى تطبيق Android يعمل داخل WebView.

لإنشاء APK:
1) فك ضغط BilliardsTutorAndroid.zip على حاسوب.
2) افتح المجلد BilliardsTutorAndroid في Android Studio.
3) اسمح لـ Android Studio بتنزيل Gradle ومكوّنات Android المطلوبة.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد الملف عادة في app/build/outputs/apk/debug/app-debug.apk

ملاحظة: لم يتم تضمين APK جاهز لأن بيئة الإنشاء هنا لا تحتوي على Android SDK أو Gradle.
